import generateElement from './generateElement.js';

function generateCart(name, age, ax) {     		   								
    const divcol = generateElement(
        'div', {
             class: 'col-md-3'
        },
            generateElement(
                'div', {
                    class: 'card',
                    class: 'mycard'
                },
                    generateElement(
                        'img', {
                            class: 'card-img-top',
                            class: 'myimg',
                            src : ax
                         }                      
                    ),
                    generateElement(
                        'div', {                            
                            class: 'card-body'                          
                        },
                            generateElement(
                                'h4', {                            
                                    class: 'card-title'                          
                                },
                                document.createTextNode(name)
                            ),
                            generateElement(
                                'p', {                            
                                    class: 'card-title'                          
                                },
                                document.createTextNode(age)
                            )                                 
                    )

            )
        
    )
   

    return divcol;

} //end function


const container = generateElement(
    'div', 
    {class: 'container'},
      generateElement('div', 
      {class:'bg-success text-center'},
            generateElement('h1', null ,
            document.createTextNode("New Gallery For you")
            )
        ),
      generateElement('div', {class: 'row'})
);

            


const userData = [
{

    name:'Poriya',
    age:30,
    ax: "images/1.jpg"
},
{
    name:'milad',
    age:24,
    ax: "images/2.jpg"
},
{
    name:'shabnam',
    age:20,
    ax: "images/3.jpg"
},
{

    name:'Poriya',
    age:30,
    ax: "images/4.jpg"
},
{
    name:'milad',
    age:24,
    ax: "images/5.jpg"
},
{
    name:'shabnam',
    age:20,
    ax: "images/6.jpg"
},
{
    name:'milad',
    age:24,
    ax: "images/7.jpg"
},
{
    name:'shabnam',
    age:20,
    ax: "images/8.jpg"
},
]

userData.forEach(data => {
// alert(data.name);
    container.appendChild(generateCart(data.name, data.age, data.ax));
})

export default container;