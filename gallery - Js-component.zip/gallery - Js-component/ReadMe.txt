For Run in Windows Local System:
run gitbash in Folder Program
run npx live-server (in gitbash)
DoubleClick newgallery.html