function render(root, child)
{
    root.appendChild(child);

}  // end root function

export default render;