import render from './render.js';
import carts from './carts.js';

render(document.body, carts);